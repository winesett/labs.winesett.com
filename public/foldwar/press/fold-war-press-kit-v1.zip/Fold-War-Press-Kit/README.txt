FOLD WAR PRESS KIT — October 20, 2026

Unfold game night. From Winesett Labs.
In development; no public download yet. Planned free U.S. launch.

Read press-kit.html or fact-sheet.txt. The assets directory includes the
transparent logo, labeled concept artwork, and real pre-release iPhone/iPad
simulator captures. These screenshots are not physical Duo testing.
Keep logo colors and proportions. Credit: Fold War / Winesett Labs.

Live press page: https://labs.winesett.com/foldwar/press/
Contact: support@winesett.com
© 2026 Cody Winesett
