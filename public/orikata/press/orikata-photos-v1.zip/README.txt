Orikata photographs — October 25, 2026
Photographs supplied by Cody Winesett. Credit: Cody Winesett / Winesett Labs.

Four AI-assisted retouches of supplied real photographs: white balance, exposure, peripheral paper packaging/labels and background cleanup. Preserve this retouching context in editorial use. These are marketing photographs, not unedited screenshots, exact UI records, or proof of complete product testing. Do not imply Apple endorsement, public availability, or support for an unverified device.

crane-4859-v1.jpg: paper crane beside the app.
fold-4862-v1.jpg: checking a real paper fold (preferred angle).
fold-4861-v1.jpg: alternate checking-a-fold angle.
heart-4866-v1.jpg: completed paper heart beside the app.

Use in coverage of Orikata. The original HEIC photographs and edit masters are retained privately. No location/device EXIF is included in these JPEG exports.
