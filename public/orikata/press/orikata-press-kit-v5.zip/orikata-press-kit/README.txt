ORIKATA: LEARN ORIGAMI
Launch press kit — November 8, 2026
From Winesett Labs. Created by Cody Winesett.

Available on the App Store, version 1.0.1. International availability is rolling out; check your storefront. EU availability awaits trader verification.
Download: https://apps.apple.com/app/apple-store/id6823809186?pt=127002238&ct=orikata_press&mt=8
Website: https://labs.winesett.com/orikata/
Support: https://labs.winesett.com/orikata/support/
Privacy: https://labs.winesett.com/orikata/privacy/
Contact: support@winesett.com

Orikata guides you through making real paper objects, one fold at a time. Follow animated demonstrations, compare your real paper, and save finished creations to your personal shelf.
Five free lessons: puppy, heart, tulip blossom, boat, traditional crane. The crane is intermediate.
iPhone with iOS 26.0 or later. A folding phone is not required.
Free. No ads, accounts, in-app purchases, or subscription. Lessons and creations work offline and stay on the device.

ASSET PROVENANCE AND USE
The four numbered PNGs are genuine unedited build-18 iPhone simulator captures from October 25, 2026, at 1320 x 2868. They show heart result/instruction, boat result, and crane result. They are not captures of the distribution binary and do not establish physical-device testing.
The six Duo images, available as separate inner/outer display downloads on the press page, are marketing compositions approved in the version 1.0.1 App Store submission. Preserve their artwork context; they are not photographs proving device behavior.
The MP4 is the approved folding brand animation: logo fades in; paper appears, folds into a crane, and fades out. It is marketing artwork, not an app preview or an animated in-app sharing feature. The app shares static keepsake images.
The crane photograph is by Cody Winesett, with AI-assisted color/background cleanup. It is a marketing photograph, not an exact UI record or hardware-validation result. No original HEIC or private edit masters are included.
Use the assets in coverage of Orikata. Credit Orikata / Winesett Labs where practical and Cody Winesett for photography. Do not imply Apple endorsement or device support beyond published compatibility. Keep captures and artwork faithful.
